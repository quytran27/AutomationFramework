## Extent Framework 4 - Community Edition

This version is Java8 only.

[Klov](https://github.com/extent-framework/klov-server) report server 0.2+ is supported with version 4.0.0+.

### Documentation

View [extentreports.com](http://extentreports.com/docs/versions/4/java/) for complete documentation.

### Samples

* [ExtentSparkReporter](http://extentreports.com/samples/spark/index.html)
* [ExtentHtmlReporter](http://extentreports.com/samples/html/index.html)

### License

Apache-2.0
